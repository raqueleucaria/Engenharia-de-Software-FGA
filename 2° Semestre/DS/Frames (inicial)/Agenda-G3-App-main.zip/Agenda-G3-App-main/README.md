# Super Agenda

### Para executar localmente:
* instale o react native
* instale o expo
* cd SuperAgenda; yarn
