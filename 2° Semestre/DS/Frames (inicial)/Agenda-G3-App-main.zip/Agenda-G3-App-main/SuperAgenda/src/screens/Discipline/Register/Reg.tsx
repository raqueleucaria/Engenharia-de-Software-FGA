import React from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';


export default function Reg() {
  return (
      alert("Registrar")
    );  
}

const Styles = StyleSheet.create({
    container: {
      alignItems: "center",
      padding: 10,
    },
   font:{
    color: "black",
    fontSize: 50
   }
   
  });