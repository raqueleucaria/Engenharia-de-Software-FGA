// import { StatusBar } from 'expo-status-bar';
// import React from 'react';
// import useForm from 'react-native-form';
// import { StyleSheet, Text, View, Button, TextInput } from 'react-native';

// export default function registerDiscipline(){
//   const = {refister, submit, errors} = useForm();

//   return(
    
//   );
// }



// class Form extends React.Component{
//   constructor(){
//     super();

//     this.state={
//       name:'',
//       description:'',
//       classTime:'',
//       color:'',
//     }

//   }

//   submit(){
//     console.warn(this.state)
//   }

//   render(){
//     return(
//       <View>
//         <TextInput 
//         placeholder="Nome da disciplina"
//         onChangeText={(text) => { this.setState({ name: text})}}
//         style={styles.btn}
//         />
//         <TextInput 
//         placeholder="Descrição"
//         onChangeText={(text) => { this.setState({ description: text})}}
//         style={styles.btn}
//         />
//         <TextInput 
//         placeholder="Horário"
//         onChangeText={(text) => { this.setState({ classTime: text})}}
//         style={styles.btn}
//         />
//         <TextInput 
//         placeholder="Cor"
//         onChangeText={(text) => { this.setState({ color: text})}}
//         style={styles.btn}
//         />

//         <Button title="Salvar" onPress={()=>{this.submit()}} />
//       </View>
//     )
//   }
// }

// export default Form
  
// const styles = StyleSheet.create({
//   btn: {
//     borderWidth: 2,
//     bordercolor: 'skyblue',
//     margin: 20,
//   },
// });          
